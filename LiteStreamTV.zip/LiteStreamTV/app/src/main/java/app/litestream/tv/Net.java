package app.litestream.tv;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Минимальный HTTP-клиент без сторонних библиотек: тайм-ауты, ограничение объёма,
 * не более 3 попыток с экспоненциальной задержкой, отмена.
 */
public final class Net {
    private Net() {}

    public static final String UA =
            "Mozilla/5.0 (Linux; Android 10; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Chrome/120.0 Safari/537.36 LiteStreamTV/1.0";

    public static final int CONNECT_TIMEOUT_MS = 8000;
    public static final int READ_TIMEOUT_MS = 12000;
    private static final int MAX_ATTEMPTS = 3;
    private static final int MAX_REDIRECTS = 6;

    public static final class Response {
        public int code;
        public String contentType = "";
        public String finalUrl;
        public String body = "";
        public boolean truncated;
    }

    public static final class HttpError extends IOException {
        public final int code;
        HttpError(int code) {
            super("HTTP " + code);
            this.code = code;
        }
    }

    public static final class Cancelled extends IOException {
        Cancelled() { super("cancelled"); }
    }

    /**
     * GET с повторами (1 с, затем 2 с). Ошибки 4xx (кроме 429) не повторяются.
     *
     * @param maxBytes      сколько байт тела читать максимум
     * @param skipMediaBody не читать тело, если сервер сразу отдаёт видео/аудио
     */
    public static Response get(String url, int maxBytes, boolean skipMediaBody, AtomicBoolean cancel)
            throws IOException {
        IOException last = null;
        for (int attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
            checkCancel(cancel);
            try {
                return once(url, maxBytes, skipMediaBody, cancel);
            } catch (Cancelled c) {
                throw c;
            } catch (HttpError e) {
                if (e.code < 500 && e.code != 429) throw e;
                last = e;
            } catch (IOException e) {
                last = e;
            }
            if (attempt < MAX_ATTEMPTS - 1) sleep(1000L << attempt, cancel);
        }
        throw last;
    }

    private static Response once(String url, int maxBytes, boolean skipMediaBody, AtomicBoolean cancel)
            throws IOException {
        String current = url;
        for (int i = 0; i < MAX_REDIRECTS; i++) {
            URL u = new URL(current);
            String proto = u.getProtocol();
            if (!"http".equals(proto) && !"https".equals(proto)) {
                throw new IOException("неподдерживаемый протокол: " + proto);
            }
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(CONNECT_TIMEOUT_MS);
            c.setReadTimeout(READ_TIMEOUT_MS);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept", "*/*");
            try {
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    if (loc == null) throw new HttpError(code);
                    current = new URL(u, loc).toString();
                    continue;
                }
                if (code >= 400) throw new HttpError(code);

                Response r = new Response();
                r.code = code;
                r.finalUrl = current;
                String ct = c.getContentType();
                r.contentType = ct == null ? "" : ct.toLowerCase(Locale.ROOT);
                if (skipMediaBody && isMediaType(r.contentType)) return r;

                try (InputStream in = new BufferedInputStream(c.getInputStream())) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream(Math.min(maxBytes, 64 * 1024));
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) != -1) {
                        checkCancel(cancel);
                        int room = maxBytes - out.size();
                        if (n > room) {
                            out.write(buf, 0, room);
                            r.truncated = true;
                            break;
                        }
                        out.write(buf, 0, n);
                    }
                    r.body = new String(out.toByteArray(), StandardCharsets.UTF_8);
                }
                return r;
            } finally {
                c.disconnect();
            }
        }
        throw new IOException("слишком много перенаправлений");
    }

    /** Ответ — само видео/аудио (тело не нужно читать). Плейлисты (*mpegurl) сюда не входят. */
    static boolean isMediaType(String ct) {
        if (ct.contains("mpegurl")) return false;
        return ct.startsWith("video/") || ct.startsWith("audio/")
                || ct.contains("dash+xml") || ct.startsWith("application/octet-stream");
    }

    private static void checkCancel(AtomicBoolean cancel) throws Cancelled {
        if (cancel != null && cancel.get()) throw new Cancelled();
    }

    private static void sleep(long ms, AtomicBoolean cancel) throws Cancelled {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            checkCancel(cancel);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new Cancelled();
            }
        }
    }
}
