package app.litestream.tv;

public final class Quality {
    private Quality() {}

    public static final String[] NAMES = {
            "Авто (адаптивно)",
            "Низкое (~360p, экономия трафика)",
            "Среднее (~480p)",
            "Высокое (максимум потока)"
    };

    public static final String[] SHORT = {"Авто", "Низкое", "Среднее", "Высокое"};
}
