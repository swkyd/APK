package app.litestream.tv;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Debug;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Главный экран: поле адреса, категории (группы плейлиста) и список.
 * Сеть — один фоновый поток; новый запрос отменяет предыдущий.
 */
public class MainActivity extends Activity {

    private static final String CAT_FAV = "fav", CAT_ALL = "all", CAT_GROUP = "g:";
    private static final int DIALOG_THEME = android.R.style.Theme_Material_Dialog_Alert;

    private EditText urlField;
    private ListView cats, items;
    private ProgressBar progress;
    private TextView status;

    private ArrayAdapter<String> catAdapter;
    private ArrayAdapter<Source> itemAdapter;
    private final List<String> catKeys = new ArrayList<>();
    private String currentCat = CAT_FAV;

    private List<Source> playlist = new ArrayList<>();
    private String playlistUrl;
    private boolean playlistTrimmed;

    private Prefs prefs;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private AtomicBoolean cancel = new AtomicBoolean();
    private boolean stopped;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = new Prefs(this);

        urlField = findViewById(R.id.url);
        cats = findViewById(R.id.cats);
        items = findViewById(R.id.items);
        progress = findViewById(R.id.progress);
        status = findViewById(R.id.status);

        catAdapter = new ArrayAdapter<>(this, R.layout.item_row);
        itemAdapter = new ArrayAdapter<>(this, R.layout.item_row);
        cats.setAdapter(catAdapter);
        items.setAdapter(itemAdapter);
        cats.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        cats.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { selectCategory(pos); }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        cats.setOnItemClickListener((p, v, pos, id) -> {
            selectCategory(pos);
            if (!itemAdapter.isEmpty()) items.requestFocus();
        });
        items.setOnItemClickListener((p, v, pos, id) -> {
            Source s = itemAdapter.getItem(pos);
            if (s == null) return;
            // Канал из плейлиста — сразу в плеер; избранное может быть чем угодно — определяем тип.
            open(s.url, s.name, !CAT_FAV.equals(currentCat), true);
        });
        items.setOnItemLongClickListener((p, v, pos, id) -> {
            Source s = itemAdapter.getItem(pos);
            if (s != null) toggleFavorite(s);
            return true;
        });

        urlField.setOnEditorActionListener((v, action, ev) -> {
            boolean enter = ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER && ev.getAction() == KeyEvent.ACTION_DOWN;
            if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE || enter) {
                openFromField();
                return true;
            }
            return false;
        });
        findViewById(R.id.btn_open).setOnClickListener(v -> openFromField());
        findViewById(R.id.btn_fav).setOnClickListener(v -> {
            String u = Util.normalizeUrl(urlField.getText().toString());
            if (u == null) {
                showError("Введите адрес в поле сверху, затем нажмите ★");
                return;
            }
            toggleFavorite(new Source(Util.hostOf(u) + " — " + shortPath(u), u, ""));
        });
        findViewById(R.id.btn_refresh).setOnClickListener(v -> refresh());
        findViewById(R.id.btn_settings).setOnClickListener(v -> showSettings());

        rebuildCategories();

        if (!handleIntent(getIntent())) {
            String last = prefs.lastPlaylist();
            if (last != null) {
                urlField.setText(last);
                open(last, null, false, false); // только обновить список, ничего не запускать
            } else {
                setStatus("Введите адрес потока, плейлиста или сайта и нажмите «Открыть»", false);
            }
        }
        cats.requestFocus();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    /** Адрес можно передать без экранной клавиатуры: adb shell am start -n app.litestream.tv/.MainActivity -d URL */
    private boolean handleIntent(Intent i) {
        Uri d = i == null ? null : i.getData();
        if (d == null) return false;
        String s = d.toString();
        urlField.setText(s);
        open(s, null, false, true);
        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();
        stopped = false;
        if (playlistTrimmed) {
            playlistTrimmed = false;
            if (playlistUrl != null) open(playlistUrl, null, false, false);
        }
        if (CAT_FAV.equals(currentCat)) rebuildCategories();
    }

    @Override
    protected void onStop() {
        stopped = true;
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        cancel.set(true);
        exec.shutdownNow();
        super.onDestroy();
    }

    /** Экран скрыт (идёт плеер), а памяти мало — выгружаем список каналов, перечитаем при возврате. */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (stopped && level >= TRIM_MEMORY_RUNNING_LOW && !playlist.isEmpty()) {
            playlist = new ArrayList<>();
            playlistTrimmed = true;
            itemAdapter.clear();
        }
    }

    // ---------------------------------------------------------------- открытие источников

    private void openFromField() {
        open(urlField.getText().toString(), null, false, true);
    }

    /**
     * @param directStream не определять тип — сразу в плеер (каналы из плейлиста)
     * @param allowLaunch  разрешено открыть плеер/страницу; false — только загрузить плейлист
     */
    private void open(String raw, String name, boolean directStream, boolean allowLaunch) {
        String url = Util.normalizeUrl(raw);
        if (url == null) {
            showError("Некорректный адрес. Нужна ссылка вида https://…");
            return;
        }
        if (directStream) {
            startPlayer(url, name);
            return;
        }
        cancel.set(true);
        final AtomicBoolean my = new AtomicBoolean();
        cancel = my;
        showLoading("Проверяю источник…");
        exec.execute(() -> {
            try {
                SourceResolver.Result r = SourceResolver.resolve(url, my);
                runOnUiThread(() -> {
                    if (my.get() || isFinishing()) return;
                    hideLoading();
                    onResolved(r, name, allowLaunch);
                });
            } catch (IOException e) {
                runOnUiThread(() -> {
                    if (my.get() || isFinishing()) return;
                    showError("Не удалось открыть: " + Util.describe(e) + ". Нажмите «Обновить», чтобы повторить.");
                });
            }
        });
    }

    private void onResolved(SourceResolver.Result r, String name, boolean allowLaunch) {
        switch (r.kind) {
            case PLAYLIST:
                playlist = r.entries;
                playlistUrl = r.url;
                prefs.setLastPlaylist(r.url);
                currentCat = CAT_ALL;
                rebuildCategories();
                setStatus("Каналов: " + playlist.size() + (r.note != null ? " · " + r.note : ""), false);
                items.requestFocus();
                break;
            case STREAM:
                setStatus("", false);
                if (allowLaunch) startPlayer(r.url, name);
                break;
            case WEB:
                setStatus(r.note != null ? r.note : "", false);
                if (allowLaunch) startWeb(r.url);
                break;
        }
    }

    private void startPlayer(String url, String name) {
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra(PlayerActivity.EXTRA_URL, url);
        i.putExtra(PlayerActivity.EXTRA_NAME, name);
        startActivity(i);
    }

    private void startWeb(String url) {
        Intent i = new Intent(this, WebActivity.class);
        i.putExtra(WebActivity.EXTRA_URL, url);
        startActivity(i);
    }

    private void refresh() {
        if (playlistUrl != null) {
            open(playlistUrl, null, false, false);
        } else {
            String typed = Util.normalizeUrl(urlField.getText().toString());
            if (typed != null) open(typed, null, false, false);
            else {
                rebuildCategories();
                setStatus("Список обновлён", false);
            }
        }
    }

    // ---------------------------------------------------------------- категории и список

    private void rebuildCategories() {
        catKeys.clear();
        List<String> labels = new ArrayList<>();
        catKeys.add(CAT_FAV);
        labels.add("★ Избранное (" + prefs.favorites().size() + ")");
        if (!playlist.isEmpty()) {
            catKeys.add(CAT_ALL);
            labels.add("Все (" + playlist.size() + ")");
            LinkedHashMap<String, Integer> groups = new LinkedHashMap<>();
            for (Source s : playlist) {
                if (s.group.isEmpty()) continue;
                Integer c = groups.get(s.group);
                groups.put(s.group, c == null ? 1 : c + 1);
            }
            for (Map.Entry<String, Integer> e : groups.entrySet()) {
                catKeys.add(CAT_GROUP + e.getKey());
                labels.add(e.getKey() + " (" + e.getValue() + ")");
            }
        }
        catAdapter.setNotifyOnChange(false);
        catAdapter.clear();
        catAdapter.addAll(labels);
        catAdapter.notifyDataSetChanged();

        int idx = catKeys.indexOf(currentCat);
        if (idx < 0) idx = 0;
        cats.setSelection(idx);
        selectCategory(idx);
    }

    private void selectCategory(int pos) {
        if (pos < 0 || pos >= catKeys.size()) return;
        String key = catKeys.get(pos);
        currentCat = key;
        cats.setItemChecked(pos, true);

        List<Source> list;
        if (key.equals(CAT_FAV)) {
            list = prefs.favorites();
        } else if (key.equals(CAT_ALL)) {
            list = playlist;
        } else {
            String g = key.substring(CAT_GROUP.length());
            list = new ArrayList<>();
            for (Source s : playlist) if (s.group.equals(g)) list.add(s);
        }
        itemAdapter.setNotifyOnChange(false);
        itemAdapter.clear();
        itemAdapter.addAll(list);
        itemAdapter.notifyDataSetChanged();

        if (key.equals(CAT_FAV) && list.isEmpty() && progress.getVisibility() != View.VISIBLE) {
            setStatus("Избранное пусто: введите адрес и нажмите ★, либо удерживайте OK на канале", false);
        }
    }

    private void toggleFavorite(Source s) {
        boolean added = prefs.toggleFavorite(s);
        toast(added ? "Добавлено в избранное" : "Удалено из избранного");
        int keepPos = items.getSelectedItemPosition();
        rebuildCategories();
        if (keepPos >= 0 && keepPos < itemAdapter.getCount()) items.setSelection(keepPos);
    }

    private static String shortPath(String url) {
        String p = Uri.parse(url).getLastPathSegment();
        return p == null ? "/" : p;
    }

    // ---------------------------------------------------------------- настройки

    private void showSettings() {
        AdBlocker ab = AdBlocker.get();
        String[] opts = {
                "Качество по умолчанию: " + Quality.SHORT[prefs.quality()],
                "Блокировка рекламы: " + (prefs.adblock() ? "включена" : "выключена"),
                "Обновить список фильтров (сейчас правил: " + (ab == null ? 0 : ab.size()) + ")",
                "Адрес списка фильтров…",
                "Удалить загруженный список фильтров",
                "Сайты без фильтрации: " + prefs.unfilteredSites().size() + " — сбросить",
                "Очистить кэш и cookies веб-страниц",
                "Потребление памяти сейчас"
        };
        new AlertDialog.Builder(this, DIALOG_THEME)
                .setTitle("Настройки")
                .setItems(opts, (d, which) -> {
                    switch (which) {
                        case 0: chooseDefaultQuality(); break;
                        case 1: prefs.setAdblock(!prefs.adblock()); showSettings(); break;
                        case 2: updateFilters(); break;
                        case 3: editFilterUrl(); break;
                        case 4:
                            if (ab != null) exec.execute(() -> {
                                ab.clearCustom();
                                runOnUiThread(() -> toast("Загруженный список удалён, остался встроенный"));
                            });
                            break;
                        case 5: prefs.clearUnfiltered(); toast("Исключения сброшены"); break;
                        case 6: clearWebData(); break;
                        case 7: showMemory(); break;
                    }
                })
                .show();
    }

    private void chooseDefaultQuality() {
        new AlertDialog.Builder(this, DIALOG_THEME)
                .setTitle("Качество по умолчанию")
                .setSingleChoiceItems(Quality.NAMES, prefs.quality(), (d, w) -> {
                    prefs.setQuality(w);
                    d.dismiss();
                    toast("Сохранено: " + Quality.SHORT[w]);
                })
                .show();
    }

    private void updateFilters() {
        AdBlocker ab = AdBlocker.get();
        if (ab == null) return;
        String url = prefs.filterUrl();
        showLoading("Загружаю список фильтров…");
        final AtomicBoolean my = new AtomicBoolean();
        exec.execute(() -> {
            try {
                int n = ab.updateFromUrl(url, my);
                runOnUiThread(() -> { hideLoading(); setStatus("Фильтры обновлены, правил: " + n, false); });
            } catch (IOException e) {
                runOnUiThread(() -> showError("Фильтры не обновлены: " + Util.describe(e)));
            }
        });
    }

    private void editFilterUrl() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        et.setSingleLine(true);
        et.setText(prefs.filterUrl());
        new AlertDialog.Builder(this, DIALOG_THEME)
                .setTitle("Список фильтров (формат hosts или ||domain^)")
                .setView(et)
                .setPositiveButton("Сохранить", (d, w) -> {
                    String u = Util.normalizeUrl(et.getText().toString());
                    if (u == null) { toast("Некорректный адрес"); return; }
                    prefs.setFilterUrl(u);
                    toast("Сохранено. Нажмите «Обновить список фильтров».");
                })
                .setNeutralButton("По умолчанию", (d, w) -> prefs.setFilterUrl(Prefs.DEFAULT_FILTER_URL))
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void clearWebData() {
        // Временный WebView нужен только для очистки дискового кэша, сразу уничтожается.
        WebView w = new WebView(this);
        w.clearCache(true);
        w.destroy();
        CookieManager.getInstance().removeAllCookies(null);
        WebStorage.getInstance().deleteAllData();
        toast("Кэш и cookies очищены");
    }

    private void showMemory() {
        Debug.MemoryInfo mi = new Debug.MemoryInfo();
        Debug.getMemoryInfo(mi);
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo sys = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(sys);
        String msg = String.format(Locale.ROOT,
                "Приложение (PSS, без процесса WebView): %.1f МБ\n"
                        + "Java-куча: %.1f из %d МБ (лимит)\n"
                        + "Свободно в системе: %d из %d МБ\n"
                        + "Система в режиме нехватки памяти: %s\n\n"
                        + "Точный замер с компьютера:\nadb shell dumpsys meminfo app.litestream.tv",
                mi.getTotalPss() / 1024f,
                (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1048576f,
                am.getMemoryClass(),
                sys.availMem / 1048576, sys.totalMem / 1048576,
                sys.lowMemory ? "да" : "нет");
        new AlertDialog.Builder(this, DIALOG_THEME)
                .setTitle("Память")
                .setMessage(msg)
                .setPositiveButton("OK", null)
                .show();
    }

    // ---------------------------------------------------------------- состояние

    private void showLoading(String msg) {
        progress.setVisibility(View.VISIBLE);
        setStatus(msg, false);
    }

    private void hideLoading() {
        progress.setVisibility(View.GONE);
    }

    private void showError(String msg) {
        progress.setVisibility(View.GONE);
        setStatus(msg, true);
    }

    @SuppressWarnings("deprecation") // getColor(int, Theme) появился только в API 23
    private void setStatus(String msg, boolean error) {
        status.setTextColor(getResources().getColor(error ? R.color.error : R.color.muted));
        status.setText(msg);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
