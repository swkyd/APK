package app.litestream.tv;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Определяет, что ввёл пользователь: видеопоток, IPTV-плейлист или веб-страницу.
 * Видео не скачивается: для медиа-ответов читаются только заголовки.
 */
public final class SourceResolver {
    private SourceResolver() {}

    public enum Kind { STREAM, PLAYLIST, WEB }

    public static final class Result {
        public Kind kind;
        public String url;            // исходный адрес (используется для воспроизведения)
        public List<Source> entries;  // для PLAYLIST
        public String note;           // пояснение для пользователя
    }

    private static final Set<String> STREAM_EXT = new HashSet<>(Arrays.asList(
            "mpd", "mp4", "m4v", "mkv", "webm", "mov", "ts", "mp3", "aac", "m4a"));
    private static final int PROBE_BYTES = 256 * 1024;
    private static final int PLAYLIST_BYTES = 3 * 1024 * 1024;

    public static Result resolve(String url, AtomicBoolean cancel) throws IOException {
        Result r = new Result();
        r.url = url;
        String ext = Util.ext(url);

        if (STREAM_EXT.contains(ext)) {
            r.kind = Kind.STREAM;
            return r;
        }

        Net.Response resp;
        try {
            int cap = ext.equals("m3u") || ext.equals("m3u8") ? PLAYLIST_BYTES : PROBE_BYTES;
            resp = Net.get(url, cap, true, cancel);
        } catch (Net.Cancelled c) {
            throw c;
        } catch (IOException e) {
            if (ext.equals("m3u8")) { // пусть плеер попробует сам
                r.kind = Kind.STREAM;
                return r;
            }
            if (ext.equals("m3u")) throw e;
            r.kind = Kind.WEB; // браузерный движок может открыть то, что не открыл простой HTTP-клиент
            r.note = "Не удалось проверить адрес (" + Util.describe(e) + "), открываю как веб-страницу";
            return r;
        }

        String body = resp.body;
        String ct = resp.contentType;

        if (body.contains("#EXT-X-")) {               // HLS-манифест
            r.kind = Kind.STREAM;
        } else if (body.contains("#EXTINF") || body.trim().startsWith("#EXTM3U")) { // IPTV-плейлист
            if (resp.truncated && body.length() < PLAYLIST_BYTES) {
                resp = Net.get(url, PLAYLIST_BYTES, false, cancel);
                body = resp.body;
            }
            r.entries = M3uParser.parse(body, resp.finalUrl);
            if (r.entries.isEmpty()) throw new IOException("плейлист пуст или в нём нет поддерживаемых ссылок");
            r.kind = Kind.PLAYLIST;
            if (resp.truncated || r.entries.size() >= M3uParser.MAX_ENTRIES) {
                r.note = "плейлист очень большой — загружены первые " + r.entries.size() + " каналов";
            }
        } else if (Net.isMediaType(ct) || ct.contains("mpegurl")) {
            r.kind = Kind.STREAM;
        } else if (ext.equals("m3u8")) {
            r.kind = Kind.STREAM;
        } else {
            r.kind = Kind.WEB;
        }
        return r;
    }
}
