package app.litestream.tv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Небольшие настройки в SharedPreferences. Списки каналов здесь не хранятся — только адреса. */
public final class Prefs {
    public static final int Q_AUTO = 0, Q_LOW = 1, Q_MID = 2, Q_HIGH = 3;
    public static final int MAX_FAVORITES = 200;
    /** Лёгкий список (~3–4 тыс. доменов). Не загружается автоматически — только по кнопке. */
    public static final String DEFAULT_FILTER_URL =
            "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext";

    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("app", Context.MODE_PRIVATE);
    }

    public int quality() { return sp.getInt("quality", Q_AUTO); }
    public void setQuality(int q) { sp.edit().putInt("quality", q).apply(); }

    public boolean adblock() { return sp.getBoolean("adblock", true); }
    public void setAdblock(boolean on) { sp.edit().putBoolean("adblock", on).apply(); }

    public String filterUrl() { return sp.getString("filter_url", DEFAULT_FILTER_URL); }
    public void setFilterUrl(String url) { sp.edit().putString("filter_url", url).apply(); }

    public String lastPlaylist() { return sp.getString("last_playlist", null); }
    public void setLastPlaylist(String url) { sp.edit().putString("last_playlist", url).apply(); }

    // ---- Сайты, для которых фильтрация отключена пользователем ----

    public Set<String> unfilteredSites() {
        return new HashSet<>(sp.getStringSet("unfiltered", Collections.<String>emptySet()));
    }

    public boolean isUnfiltered(String site) {
        return sp.getStringSet("unfiltered", Collections.<String>emptySet()).contains(site);
    }

    public void setUnfiltered(String site, boolean unfiltered) {
        Set<String> s = unfilteredSites();
        if (unfiltered) s.add(site); else s.remove(site);
        sp.edit().putStringSet("unfiltered", s).apply();
    }

    public void clearUnfiltered() { sp.edit().remove("unfiltered").apply(); }

    // ---- Избранное ----

    public List<Source> favorites() {
        List<Source> out = new ArrayList<>();
        String raw = sp.getString("favorites", "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new Source(o.optString("n"), o.optString("u"), o.optString("g")));
            }
        } catch (JSONException ignored) {
        }
        return out;
    }

    public boolean isFavorite(String url) {
        for (Source s : favorites()) if (s.url.equals(url)) return true;
        return false;
    }

    /** @return true — добавлено, false — удалено. */
    public boolean toggleFavorite(Source src) {
        List<Source> list = favorites();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).url.equals(src.url)) {
                list.remove(i);
                saveFavorites(list);
                return false;
            }
        }
        if (list.size() >= MAX_FAVORITES) list.remove(list.size() - 1);
        list.add(0, src);
        saveFavorites(list);
        return true;
    }

    private void saveFavorites(List<Source> list) {
        JSONArray arr = new JSONArray();
        try {
            for (Source s : list) {
                JSONObject o = new JSONObject();
                o.put("n", s.name);
                o.put("u", s.url);
                o.put("g", s.group);
                arr.put(o);
            }
        } catch (JSONException ignored) {
        }
        sp.edit().putString("favorites", arr.toString()).apply();
    }
}
