package app.litestream.tv;

import android.app.Application;

/** Процесс приложения. Никаких фоновых служб и автозапусков. */
public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        // Правила блокировки читаются в фоновом потоке с низким приоритетом.
        AdBlocker.init(this);
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= TRIM_MEMORY_RUNNING_LOW) {
            AdBlocker blocker = AdBlocker.get();
            if (blocker != null) blocker.trimCache();
        }
    }
}
