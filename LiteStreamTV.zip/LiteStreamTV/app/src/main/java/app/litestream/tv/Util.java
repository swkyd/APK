package app.litestream.tv;

import android.net.Uri;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import javax.net.ssl.SSLException;

public final class Util {
    private Util() {}

    private static final Set<String> SECOND_LEVEL =
            new HashSet<>(Arrays.asList("co", "com", "net", "org", "gov", "edu", "ac", "or", "ne"));

    /** Приводит ввод пользователя к http(s)-адресу или возвращает null, если адрес недопустим. */
    public static String normalizeUrl(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.isEmpty() || s.contains(" ")) return null;
        if (!s.matches("(?i)^[a-z][a-z0-9+.-]*://.*")) s = "https://" + s;
        Uri u = Uri.parse(s);
        String scheme = u.getScheme();
        if (scheme == null) return null;
        scheme = scheme.toLowerCase(Locale.ROOT);
        if (!scheme.equals("http") && !scheme.equals("https")) return null;
        String host = u.getHost();
        if (host == null || host.isEmpty()) return null;
        return s;
    }

    /** Расширение последнего сегмента пути, в нижнем регистре ("m3u8", "mpd"…). */
    public static String ext(String url) {
        if (url == null) return "";
        String p = Uri.parse(url).getPath();
        if (p == null) return "";
        String last = p.substring(p.lastIndexOf('/') + 1);
        int dot = last.lastIndexOf('.');
        return dot < 0 ? "" : last.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    /** Упрощённый «сайт» (регистрируемый домен): video.example.com → example.com, a.b.co.uk → b.co.uk. */
    public static String siteKey(String host) {
        if (host == null) return "";
        String h = host.toLowerCase(Locale.ROOT);
        String[] p = h.split("\\.");
        if (p.length <= 2) return h;
        String last = p[p.length - 1];
        String second = p[p.length - 2];
        if (last.length() == 2 && SECOND_LEVEL.contains(second)) {
            return p[p.length - 3] + "." + second + "." + last;
        }
        return second + "." + last;
    }

    public static String hostOf(String url) {
        String h = Uri.parse(url).getHost();
        return h == null ? "" : h;
    }

    /** Понятное описание сетевой ошибки. */
    public static String describe(IOException e) {
        if (e instanceof Net.HttpError) {
            int code = ((Net.HttpError) e).code;
            if (code == 403) return "доступ запрещён сервером (HTTP 403)";
            if (code == 404) return "адрес не найден (HTTP 404)";
            if (code == 429) return "сервер ограничил число запросов (HTTP 429), попробуйте позже";
            return "сервер ответил ошибкой HTTP " + code;
        }
        if (e instanceof Net.Cancelled) return "отменено";
        if (e instanceof SocketTimeoutException) return "сервер не ответил вовремя (тайм-аут)";
        if (e instanceof UnknownHostException) return "нет интернета или сайт не найден";
        if (e instanceof SSLException) return "ошибка защищённого соединения";
        String m = e.getMessage();
        return m == null ? e.getClass().getSimpleName() : m;
    }
}
