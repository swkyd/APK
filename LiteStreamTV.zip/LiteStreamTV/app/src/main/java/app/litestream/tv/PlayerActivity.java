package app.litestream.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.VideoSize;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

/**
 * Полноэкранный плеер на Media3/ExoPlayer.
 *
 * Память: один экземпляр плеера, создаётся в onStart и полностью освобождается в onStop
 * (декодер, буферы, сетевые загрузки). Буфер ограничен по времени и по байтам.
 *
 * Качество: переключается через TrackSelectionParameters выбором реальных вариантов
 * HLS/DASH-потока (по разрешению, а если оно не указано — по битрейту), без перезапуска.
 * Если вариант один — пользователю честно сообщается, что переключение недоступно.
 */
public class PlayerActivity extends Activity implements Player.Listener {

    public static final String EXTRA_URL = "url";
    public static final String EXTRA_NAME = "name";

    private static final int MAX_RETRIES = 5;
    private static final long HIDE_DELAY_MS = 5000;
    private static final int DIALOG_THEME = android.R.style.Theme_Material_Dialog_Alert;

    private ExoPlayer player;
    private FrameLayout videoFrame;
    private SurfaceView surface;
    private View controls;
    private ProgressBar spinner;
    private TextView title, info, status;
    private Button btnPlay, btnRestart, btnQuality, btnWeb;

    private final Handler h = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private String url, name;
    private int quality;
    private int retries;
    private boolean inError;
    private boolean singleQualityWarned;
    private float videoAspect;

    /** Доступные (поддерживаемые устройством) варианты видео в текущем потоке. */
    private final TreeSet<Integer> heights = new TreeSet<>();
    private final TreeSet<Integer> bitrates = new TreeSet<>();

    private ConnectivityManager.NetworkCallback netCallback;

    private final Runnable hideControls = () -> {
        if (controls != null && player != null && player.isPlaying() && !inError) controls.setVisibility(View.GONE);
    };
    private final Runnable retryRunnable = this::reconnect;

    // ---------------------------------------------------------------- жизненный цикл

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_player);
        prefs = new Prefs(this);
        quality = prefs.quality();
        url = getIntent().getStringExtra(EXTRA_URL);
        name = getIntent().getStringExtra(EXTRA_NAME);
        if (url == null) {
            finish();
            return;
        }

        videoFrame = findViewById(R.id.video_frame);
        surface = findViewById(R.id.surface);
        controls = findViewById(R.id.controls);
        spinner = findViewById(R.id.spinner);
        title = findViewById(R.id.title);
        info = findViewById(R.id.info);
        status = findViewById(R.id.status);
        btnPlay = findViewById(R.id.btn_play);
        btnRestart = findViewById(R.id.btn_restart);
        btnQuality = findViewById(R.id.btn_quality);
        btnWeb = findViewById(R.id.btn_web);

        title.setText(name != null ? name : url);
        btnPlay.setOnClickListener(v -> togglePlay());
        btnRestart.setOnClickListener(v -> restart());
        btnQuality.setOnClickListener(v -> showQualityDialog());
        btnWeb.setOnClickListener(v -> {
            Intent i = new Intent(this, WebActivity.class);
            i.putExtra(WebActivity.EXTRA_URL, url);
            startActivity(i);
            finish();
        });
        videoFrame.addOnLayoutChangeListener((v, l, t, r, bt, ol, ot, or, ob) -> {
            if (r - l != or - ol || bt - t != ob - ot) videoFrame.post(this::applyAspect);
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        hideSystemUi();
        initPlayer();
        registerNetworkCallback();
    }

    @Override
    protected void onStop() {
        unregisterNetworkCallback();
        releasePlayer();
        super.onStop();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    // ---------------------------------------------------------------- плеер

    private void initPlayer() {
        if (player != null) return;
        inError = false;
        singleQualityWarned = false;
        btnWeb.setVisibility(View.GONE);

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(Net.UA)
                .setConnectTimeoutMs(Net.CONNECT_TIMEOUT_MS)
                .setReadTimeoutMs(15_000)
                .setAllowCrossProtocolRedirects(true);
        DataSource.Factory dataSource = new DefaultDataSource.Factory(this, http);

        DefaultMediaSourceFactory mediaSources = new DefaultMediaSourceFactory(dataSource)
                .setLoadErrorHandlingPolicy(new DefaultLoadErrorHandlingPolicy(3));

        // Буфер: 12–30 с, но не более 24 МБ — ограничение для устройств с 2 ГБ ОЗУ.
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(12_000, 30_000, 1_500, 3_000)
                .setTargetBufferBytes(24 * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(false)
                .build();

        // Аппаратные декодеры системы; при сбое — запасной декодер, если он есть.
        DefaultRenderersFactory renderers = new DefaultRenderersFactory(this)
                .setEnableDecoderFallback(true);

        player = new ExoPlayer.Builder(this, renderers)
                .setTrackSelector(new DefaultTrackSelector(this))
                .setLoadControl(loadControl)
                .setMediaSourceFactory(mediaSources)
                .build();
        player.addListener(this);
        player.setVideoSurfaceView(surface);
        applyQualityConstraints();

        MediaItem.Builder item = new MediaItem.Builder().setUri(url);
        String ext = Util.ext(url);
        if ("m3u8".equals(ext)) item.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if ("mpd".equals(ext)) item.setMimeType(MimeTypes.APPLICATION_MPD);

        player.setMediaItem(item.build());
        player.setPlayWhenReady(true);
        player.prepare();
        showSpinner("Подключение…");
        showControls();
        updateInfo();
    }

    private void releasePlayer() {
        h.removeCallbacks(retryRunnable);
        h.removeCallbacks(hideControls);
        if (player != null) {
            player.removeListener(this);
            player.clearVideoSurface();
            player.release(); // освобождает декодер, буферы и сетевые загрузки
            player = null;
        }
        heights.clear();
        bitrates.clear();
    }

    /** Полный перезапуск: новый плеер, сброс счётчика повторов. */
    private void restart() {
        retries = 0;
        releasePlayer();
        initPlayer();
    }

    /** Повторное подключение после ошибки (с сохранением позиции для записей). */
    private void reconnect() {
        if (player == null) return;
        showSpinner("Повторное подключение…");
        if (player.isCurrentMediaItemLive() || player.getDuration() == C.TIME_UNSET) {
            player.seekToDefaultPosition();
        }
        player.prepare();
        player.play();
    }

    private void togglePlay() {
        if (player == null) return;
        if (inError) {
            retries = 0;
            reconnect();
            return;
        }
        player.setPlayWhenReady(!player.getPlayWhenReady());
    }

    // ---------------------------------------------------------------- качество

    private void applyQualityConstraints() {
        if (player == null) return;
        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon()
                .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                .clearVideoSizeConstraints()
                .setMaxVideoBitrate(Integer.MAX_VALUE)
                .setForceLowestBitrate(false)
                .setForceHighestSupportedBitrate(false);

        // Если в манифесте не указаны разрешения, различаем варианты по битрейту.
        boolean byBitrate = heights.size() < 2 && bitrates.size() >= 2;
        switch (quality) {
            case Prefs.Q_LOW:
                if (byBitrate) b.setForceLowestBitrate(true);
                else b.setMaxVideoSize(Integer.MAX_VALUE, 360);
                break;
            case Prefs.Q_MID:
                if (byBitrate) b.setMaxVideoBitrate(medianBitrate());
                else b.setMaxVideoSize(Integer.MAX_VALUE, 480);
                break;
            case Prefs.Q_HIGH:
                b.setForceHighestSupportedBitrate(true);
                break;
            default:
                break; // Авто — адаптивный выбор ExoPlayer
        }
        player.setTrackSelectionParameters(b.build());
    }

    private int medianBitrate() {
        List<Integer> list = new ArrayList<>(bitrates);
        return list.isEmpty() ? Integer.MAX_VALUE : list.get(list.size() / 2);
    }

    private int variantCount() {
        return heights.size() >= 2 ? heights.size() : bitrates.size();
    }

    private String availableText() {
        if (heights.size() >= 2) {
            StringBuilder sb = new StringBuilder();
            for (int hgt : heights) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(hgt).append('p');
            }
            return sb.toString();
        }
        if (bitrates.size() >= 2) return bitrates.size() + " вариантов битрейта";
        if (!heights.isEmpty()) return "только " + heights.first() + "p";
        return "одно качество";
    }

    private void showQualityDialog() {
        new AlertDialog.Builder(this, DIALOG_THEME)
                .setTitle("Качество · в потоке: " + availableText())
                .setSingleChoiceItems(Quality.NAMES, quality, (d, w) -> {
                    quality = w;
                    prefs.setQuality(w);
                    applyQualityConstraints();
                    updateInfo();
                    d.dismiss();
                    if (w != Prefs.Q_AUTO && variantCount() < 2) {
                        toast("Источник отдаёт одно качество — переключение недоступно");
                    }
                })
                .show();
    }

    // ---------------------------------------------------------------- Player.Listener

    @Override
    public void onTracksChanged(Tracks tracks) {
        heights.clear();
        bitrates.clear();
        for (Tracks.Group g : tracks.getGroups()) {
            if (g.getType() != C.TRACK_TYPE_VIDEO) continue;
            for (int i = 0; i < g.length; i++) {
                if (!g.isTrackSupported(i)) continue; // не предлагаем то, что устройство не декодирует
                Format f = g.getTrackFormat(i);
                if (f.height > 0) heights.add(f.height);
                if (f.bitrate > 0) bitrates.add(f.bitrate);
            }
        }
        applyQualityConstraints(); // параметры не изменились — плеер проигнорирует вызов
        updateInfo();
        if (quality != Prefs.Q_AUTO && !singleQualityWarned && (!heights.isEmpty() || !bitrates.isEmpty())
                && variantCount() < 2) {
            singleQualityWarned = true;
            toast("Источник отдаёт одно качество (" + availableText() + ") — переключение недоступно");
        }
    }

    @Override
    public void onPlaybackStateChanged(int state) {
        switch (state) {
            case Player.STATE_BUFFERING:
                showSpinner(retries > 0 ? status.getText().toString() : "Буферизация…");
                break;
            case Player.STATE_READY:
                hideSpinner();
                retries = 0;
                inError = false;
                btnWeb.setVisibility(View.GONE);
                status.setText("");
                scheduleHide();
                break;
            case Player.STATE_ENDED:
                hideSpinner();
                status.setText("Воспроизведение завершено");
                showControlsSticky();
                break;
            default:
                break;
        }
        updateInfo();
    }

    @Override
    public void onIsPlayingChanged(boolean playing) {
        btnPlay.setText(playing ? "⏸ Пауза" : "▶ Играть");
        if (playing) scheduleHide();
        else if (controls.getVisibility() != View.VISIBLE) showControlsSticky();
    }

    @Override
    public void onVideoSizeChanged(VideoSize vs) {
        if (vs.width > 0 && vs.height > 0) {
            videoAspect = vs.width * vs.pixelWidthHeightRatio / vs.height;
            applyAspect();
        }
        updateInfo();
    }

    @Override
    public void onPlayerError(PlaybackException e) {
        hideSpinner();
        if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW && player != null) {
            player.seekToDefaultPosition(); // отстали от эфира — возвращаемся к «живой» точке
            player.prepare();
            return;
        }
        inError = true;
        String why = describe(e);
        boolean parse = e.errorCode >= 3000 && e.errorCode < 4000;
        btnWeb.setVisibility(parse ? View.VISIBLE : View.GONE);

        if (isRecoverable(e) && retries < MAX_RETRIES) {
            long delay = Math.min(16_000L, 1000L << retries); // 1, 2, 4, 8, 16 с
            retries++;
            status.setText(why + "\nПовтор через " + (delay / 1000) + " с (попытка " + retries + " из " + MAX_RETRIES + ")");
            h.removeCallbacks(retryRunnable);
            h.postDelayed(retryRunnable, delay);
        } else {
            status.setText(why + "\nНажмите «Перезапуск», чтобы попробовать снова.");
        }
        showControlsSticky();
        (parse ? btnWeb : btnRestart).requestFocus();
    }

    private static boolean isRecoverable(PlaybackException e) {
        int c = e.errorCode;
        if (c >= 2000 && c < 3000) {
            return c != PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND
                    && c != PlaybackException.ERROR_CODE_IO_NO_PERMISSION
                    && c != PlaybackException.ERROR_CODE_IO_CLEARTEXT_NOT_PERMITTED
                    && c != PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE;
        }
        return c == PlaybackException.ERROR_CODE_TIMEOUT || c == PlaybackException.ERROR_CODE_UNSPECIFIED;
    }

    private static String describe(PlaybackException e) {
        int c = e.errorCode;
        if (c == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED) return "Нет соединения с сервером потока.";
        if (c == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT || c == PlaybackException.ERROR_CODE_TIMEOUT)
            return "Сервер потока не отвечает (тайм-аут).";
        if (c == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS) {
            Throwable t = e.getCause();
            if (t instanceof HttpDataSource.InvalidResponseCodeException) {
                int code = ((HttpDataSource.InvalidResponseCodeException) t).responseCode;
                if (code == 403) return "Сервер запретил доступ к потоку (HTTP 403): ссылка устарела или требует авторизации.";
                if (code == 404) return "Поток не найден (HTTP 404): трансляция могла закончиться.";
                return "Сервер потока вернул ошибку HTTP " + code + ".";
            }
            return "Сервер потока вернул ошибку.";
        }
        if (c == PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE)
            return "По ссылке не видео. Возможно, это веб-страница.";
        if (c >= 3000 && c < 4000)
            return "Формат не распознан: ссылка ведёт не на видеопоток (например, на страницу сайта) или формат не поддерживается.";
        if (c >= 4000 && c < 5000)
            return "Устройство не может декодировать этот поток. Выберите качество ниже.";
        if (c >= 6000 && c < 7000)
            return "Поток защищён DRM — воспроизведение в этом приложении не поддерживается.";
        return "Ошибка воспроизведения (" + e.getErrorCodeName() + ").";
    }

    // ---------------------------------------------------------------- сеть

    private void registerNetworkCallback() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null || netCallback != null) return;
        netCallback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(Network network) {
                // Сеть вернулась — если стоим в ошибке, подключаемся сразу, не дожидаясь таймера.
                h.post(() -> {
                    if (inError && player != null) {
                        retries = 0;
                        h.removeCallbacks(retryRunnable);
                        reconnect();
                    }
                });
            }

            @Override
            public void onLost(Network network) {
                h.post(() -> {
                    if (player != null && !player.isPlaying()) status.setText("Нет подключения к сети…");
                });
            }
        };
        try {
            NetworkRequest req = new NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
            cm.registerNetworkCallback(req, netCallback);
        } catch (RuntimeException ignored) {
            netCallback = null;
        }
    }

    private void unregisterNetworkCallback() {
        if (netCallback == null) return;
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            if (cm != null) cm.unregisterNetworkCallback(netCallback);
        } catch (RuntimeException ignored) {
        }
        netCallback = null;
    }

    // ---------------------------------------------------------------- пульт

    @Override
    public boolean dispatchKeyEvent(KeyEvent ev) {
        int k = ev.getKeyCode();
        if (ev.getAction() == KeyEvent.ACTION_DOWN) {
            switch (k) {
                case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                    togglePlay(); showControls(); return true;
                case KeyEvent.KEYCODE_MEDIA_PLAY:
                    if (player != null) player.play(); showControls(); return true;
                case KeyEvent.KEYCODE_MEDIA_PAUSE:
                    if (player != null) player.pause(); showControls(); return true;
                case KeyEvent.KEYCODE_BACK:
                    if (controls.getVisibility() == View.VISIBLE && player != null && player.isPlaying()) {
                        controls.setVisibility(View.GONE);
                        return true;
                    }
                    break;
                default:
                    break;
            }
            if (controls.getVisibility() != View.VISIBLE) {
                if ((k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT) && canSeek()) {
                    long pos = player.getCurrentPosition() + (k == KeyEvent.KEYCODE_DPAD_LEFT ? -10_000 : 10_000);
                    player.seekTo(Math.max(0, pos));
                    showControls();
                    return true;
                }
                if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_DPAD_UP
                        || k == KeyEvent.KEYCODE_DPAD_DOWN || k == KeyEvent.KEYCODE_MENU
                        || k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    showControls();
                    return true;
                }
            } else {
                scheduleHide();
            }
        }
        return super.dispatchKeyEvent(ev);
    }

    /** Перемотка только для записей: у прямых трансляций её нет. */
    private boolean canSeek() {
        return player != null && player.isCurrentMediaItemSeekable() && !player.isCurrentMediaItemLive();
    }

    // ---------------------------------------------------------------- интерфейс

    private void showControls() {
        controls.setVisibility(View.VISIBLE);
        if (!controls.hasFocus()) btnPlay.requestFocus();
        scheduleHide();
    }

    private void showControlsSticky() {
        controls.setVisibility(View.VISIBLE);
        if (!controls.hasFocus()) btnPlay.requestFocus();
        h.removeCallbacks(hideControls);
    }

    private void scheduleHide() {
        h.removeCallbacks(hideControls);
        h.postDelayed(hideControls, HIDE_DELAY_MS);
    }

    private void showSpinner(String msg) {
        spinner.setVisibility(View.VISIBLE);
        if (msg != null) status.setText(msg);
    }

    private void hideSpinner() {
        spinner.setVisibility(View.GONE);
    }

    private void updateInfo() {
        StringBuilder sb = new StringBuilder();
        if (player != null && player.isCurrentMediaItemLive()) sb.append("● Прямой эфир · ");
        sb.append("Качество: ").append(Quality.SHORT[quality]);
        Format f = player == null ? null : player.getVideoFormat();
        if (f != null) {
            if (f.height > 0) sb.append(" · сейчас ").append(f.height).append('p');
            if (f.bitrate > 0) sb.append(" · ").append(f.bitrate / 1000).append(" кбит/с");
        }
        if (!heights.isEmpty() || !bitrates.isEmpty()) sb.append(" · в потоке: ").append(availableText());
        info.setText(sb);
    }

    /** Вписывает видео в экран с сохранением пропорций (без лишних библиотек). */
    private void applyAspect() {
        int fw = videoFrame.getWidth(), fh = videoFrame.getHeight();
        if (fw == 0 || fh == 0 || videoAspect <= 0) return;
        int w = fw, hgt = Math.round(fw / videoAspect);
        if (hgt > fh) {
            hgt = fh;
            w = Math.round(fh * videoAspect);
        }
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) surface.getLayoutParams();
        if (lp.width != w || lp.height != hgt) {
            lp.width = w;
            lp.height = hgt;
            lp.gravity = Gravity.CENTER;
            surface.setLayoutParams(lp);
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
