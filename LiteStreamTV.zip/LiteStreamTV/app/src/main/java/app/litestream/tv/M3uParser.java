package app.litestream.tv;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Разбор IPTV-плейлистов M3U/M3U8 (#EXTINF, group-title, #EXTGRP). Логотипы не загружаются. */
public final class M3uParser {
    private M3uParser() {}

    /** Ограничение на число каналов, чтобы огромный плейлист не съел память. */
    public static final int MAX_ENTRIES = 5000;
    private static final Pattern GROUP = Pattern.compile("group-title=\"([^\"]*)\"");

    public static List<Source> parse(String text, String baseUrl) {
        List<Source> out = new ArrayList<>();
        String name = null, group = null, extGrp = null;
        URL base = null;
        try {
            base = new URL(baseUrl);
        } catch (Exception ignored) {
        }
        try (BufferedReader r = new BufferedReader(new StringReader(text))) {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                if (line.startsWith("#EXTINF")) {
                    name = titleOf(line);
                    Matcher m = GROUP.matcher(line);
                    group = m.find() ? m.group(1).trim() : null;
                } else if (line.startsWith("#EXTGRP:")) {
                    extGrp = line.substring(8).trim();
                } else if (line.startsWith("#")) {
                    // прочие директивы игнорируем
                } else {
                    String url = resolve(base, line);
                    if (url != null) {
                        String g = (group != null && !group.isEmpty()) ? group : extGrp;
                        out.add(new Source(name, url, g));
                        if (out.size() >= MAX_ENTRIES) break;
                    }
                    name = null;
                    group = null;
                    extGrp = null;
                }
            }
        } catch (IOException ignored) {
            // StringReader не бросает
        }
        return out;
    }

    /** Название — всё после первой запятой вне кавычек (в самом названии запятые допустимы). */
    private static String titleOf(String line) {
        boolean inQuote = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') inQuote = !inQuote;
            else if (c == ',' && !inQuote) return line.substring(i + 1).trim();
        }
        return null;
    }

    private static String resolve(URL base, String ref) {
        try {
            String lower = ref.toLowerCase(Locale.ROOT);
            String abs;
            if (lower.startsWith("http://") || lower.startsWith("https://")) abs = ref;
            else if (base != null && !lower.matches("^[a-z][a-z0-9+.-]*:.*")) abs = new URL(base, ref).toString();
            else return null; // rtmp://, udp:// и т.п. не поддерживаются
            return abs;
        } catch (Exception e) {
            return null;
        }
    }
}
