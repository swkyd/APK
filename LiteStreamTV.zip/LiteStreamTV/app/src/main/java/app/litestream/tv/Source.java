package app.litestream.tv;

/** Один элемент списка: канал из плейлиста или сохранённый источник. */
public final class Source {
    public final String name;
    public final String url;
    public final String group;

    public Source(String name, String url, String group) {
        this.name = (name == null || name.isEmpty()) ? url : name;
        this.url = url;
        this.group = group == null ? "" : group;
    }

    @Override
    public String toString() {
        return name;
    }
}
