package app.litestream.tv;

import android.content.Context;
import android.util.LruCache;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Лёгкий блокировщик по доменам: HashSet + проверка суффиксов (ads.x.com → x.com).
 * Без VPN, прокси и фоновых служб. Работает внутри WebView через shouldInterceptRequest.
 *
 * Источники правил:
 *  1) встроенный список assets/adblock_hosts.txt;
 *  2) загружаемый пользователем список (формат hosts или доменные правила AdBlock "||domain^"),
 *     хранится в files/filters.txt, не более MAX_DOWNLOAD байт и MAX_RULES правил.
 */
public final class AdBlocker {
    public static final int MAX_RULES = 120_000;
    public static final int MAX_DOWNLOAD = 4 * 1024 * 1024;

    private static volatile AdBlocker instance;

    private final Context app;
    private volatile Set<String> hosts = Collections.emptySet();
    private final LruCache<String, Boolean> cache = new LruCache<>(256);

    private AdBlocker(Context c) {
        app = c.getApplicationContext();
    }

    public static void init(Context c) {
        if (instance == null) {
            synchronized (AdBlocker.class) {
                if (instance == null) {
                    instance = new AdBlocker(c);
                    instance.reloadAsync();
                }
            }
        }
    }

    public static AdBlocker get() {
        return instance;
    }

    public int size() {
        return hosts.size();
    }

    public void trimCache() {
        cache.evictAll();
    }

    public void reloadAsync() {
        Thread t = new Thread(this::reload, "adblock-load");
        t.setPriority(Thread.MIN_PRIORITY);
        t.start();
    }

    public synchronized int reload() {
        HashSet<String> set = new HashSet<>(4096);
        try (InputStream in = app.getAssets().open("adblock_hosts.txt")) {
            read(new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)), set);
        } catch (IOException ignored) {
        }
        File f = customFile();
        if (f.exists()) {
            try (InputStream in = new FileInputStream(f)) {
                read(new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8), 16 * 1024), set);
            } catch (IOException ignored) {
            }
        }
        hosts = set;
        cache.evictAll();
        return set.size();
    }

    /** Загружает список фильтров по адресу. Вызывать не в UI-потоке. @return число правил после загрузки */
    public int updateFromUrl(String url, AtomicBoolean cancel) throws IOException {
        Net.Response r = Net.get(url, MAX_DOWNLOAD, false, cancel);
        int valid = 0;
        try (BufferedReader br = new BufferedReader(new StringReader(r.body))) {
            String line;
            while ((line = br.readLine()) != null) if (parseLine(line) != null) valid++;
        }
        if (valid == 0) throw new IOException("в файле нет ни одного доменного правила — проверьте адрес списка");
        File tmp = new File(app.getFilesDir(), "filters.tmp");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8)) {
            w.write(r.body);
        }
        File dst = customFile();
        if (dst.exists() && !dst.delete()) throw new IOException("не удалось заменить старый список");
        if (!tmp.renameTo(dst)) throw new IOException("не удалось сохранить список");
        return reload();
    }

    public void clearCustom() {
        //noinspection ResultOfMethodCallIgnored
        customFile().delete();
        reload();
    }

    private File customFile() {
        return new File(app.getFilesDir(), "filters.txt");
    }

    private static void read(BufferedReader r, Set<String> out) throws IOException {
        String line;
        while ((line = r.readLine()) != null && out.size() < MAX_RULES) {
            String h = parseLine(line);
            if (h != null) out.add(h);
        }
    }

    /** Возвращает домен из строки правила или null, если правило не доменное (косметика, исключения, пути). */
    static String parseLine(String raw) {
        String s = raw.trim();
        if (s.isEmpty()) return null;
        char c0 = s.charAt(0);
        if (c0 == '#' || c0 == '!' || c0 == '[') return null;
        if (s.startsWith("@@") || s.contains("##") || s.contains("#@#") || s.contains("#?#")) return null;

        if (s.startsWith("||")) {
            s = s.substring(2);
            int end = s.length();
            for (int i = 0; i < s.length(); i++) {
                char ch = s.charAt(i);
                if (ch == '^' || ch == '/' || ch == '$' || ch == '*' || ch == '|') {
                    end = i;
                    break;
                }
            }
            String rest = s.substring(end);
            // Только «чистые» доменные правила; правила с путями и сложными опциями пропускаем.
            if (!(rest.isEmpty() || rest.equals("^") || rest.equals("^|")
                    || rest.equals("^$third-party") || rest.equals("^$all"))) return null;
            s = s.substring(0, end);
        } else {
            int hash = s.indexOf('#');
            if (hash >= 0) s = s.substring(0, hash).trim();
            if (s.isEmpty()) return null;
            String[] parts = s.split("\\s+");
            if (parts.length >= 2) {
                String ip = parts[0];
                if (ip.equals("0.0.0.0") || ip.equals("127.0.0.1") || ip.equals("::") || ip.equals("::1")) s = parts[1];
                else return null;
            } else {
                s = parts[0];
            }
        }

        s = s.toLowerCase(Locale.ROOT);
        if (s.equals("localhost") || s.equals("0.0.0.0") || s.equals("broadcasthost")
                || s.endsWith(".localdomain") || s.endsWith(".local")) return null;
        if (s.indexOf('.') <= 0 || s.endsWith(".")) return null;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            boolean ok = (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '.' || ch == '-' || ch == '_';
            if (!ok) return null;
        }
        return s;
    }

    /** Потокобезопасно; вызывается из сетевого потока WebView. */
    public boolean isBlocked(String host) {
        if (host == null || host.isEmpty()) return false;
        Set<String> set = hosts;
        if (set.isEmpty()) return false;
        String h = host.toLowerCase(Locale.ROOT);
        Boolean cached = cache.get(h);
        if (cached != null) return cached;
        boolean res = false;
        String cur = h;
        while (true) {
            if (set.contains(cur)) {
                res = true;
                break;
            }
            int dot = cur.indexOf('.');
            if (dot < 0) break;
            cur = cur.substring(dot + 1);
            if (cur.indexOf('.') < 0) break; // зону верхнего уровня ("com") не проверяем
        }
        cache.put(h, res);
        return res;
    }
}
