package app.litestream.tv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/** Экранный курсор для управления веб-страницей стрелками пульта. Не перехватывает касания. */
public class CursorView extends View {
    public static final int EDGE_NONE = 0, EDGE_LEFT = 1, EDGE_RIGHT = 2, EDGE_TOP = 4, EDGE_BOTTOM = 8;

    private float x = -1, y = -1;
    private final float radius;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

    public CursorView(Context c) {
        this(c, null);
    }

    public CursorView(Context c, AttributeSet a) {
        super(c, a);
        float d = getResources().getDisplayMetrics().density;
        radius = 9 * d;
        fill.setColor(0xDDFFFFFF);
        stroke.setColor(0xFF1E88E5);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3 * d);
        setFocusable(false);
        setClickable(false);
        setWillNotDraw(false);
    }

    public float cx() { return x; }
    public float cy() { return y; }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (x < 0) {
            x = w / 2f;
            y = h / 2f;
        }
        x = Math.min(Math.max(x, 0), Math.max(0, w - 1));
        y = Math.min(Math.max(y, 0), Math.max(0, h - 1));
    }

    /** Сдвигает курсор; возвращает флаги краёв, в которые он упёрся. */
    public int moveBy(float dx, float dy, float minY) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return EDGE_NONE;
        float nx = x + dx, ny = y + dy;
        int edge = EDGE_NONE;
        if (nx < 0) { nx = 0; edge |= EDGE_LEFT; }
        if (nx > w - 1) { nx = w - 1; edge |= EDGE_RIGHT; }
        if (ny < minY) { ny = minY; edge |= EDGE_TOP; }
        if (ny > h - 1) { ny = h - 1; edge |= EDGE_BOTTOM; }
        int r = (int) radius + 4;
        invalidate((int) x - r, (int) y - r, (int) x + r, (int) y + r);
        x = nx;
        y = ny;
        invalidate((int) x - r, (int) y - r, (int) x + r, (int) y + r);
        return edge;
    }

    @Override
    protected void onDraw(Canvas c) {
        if (x < 0) return;
        c.drawCircle(x, y, radius, fill);
        c.drawCircle(x, y, radius, stroke);
    }
}
