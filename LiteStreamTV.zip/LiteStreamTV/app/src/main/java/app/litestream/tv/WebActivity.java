package app.litestream.tv;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Лёгкий просмотр веб-страницы, адрес которой ввёл пользователь.
 *
 * — один WebView, создаётся в коде и полностью уничтожается в onDestroy (без накопления контекстов);
 * — блокировка рекламных доменов до загрузки (shouldInterceptRequest), всплывающих окон,
 *   автоматических редиректов на сторонние сайты и переходов во внешние приложения;
 * — запросы самого сайта и манифесты видео (.m3u8/.mpd) не блокируются никогда;
 * — фильтрацию можно выключить для конкретного сайта, если она ломает его плеер;
 * — экранный курсор: стрелки двигают, OK — нажатие, у края — прокрутка, Menu — панель.
 */
public class WebActivity extends Activity {

    public static final String EXTRA_URL = "url";

    private static final String COSMETIC_JS =
            "(function(){if(document.getElementById('lstv-css'))return;"
                    + "var s=document.createElement('style');s.id='lstv-css';"
                    + "s.textContent='ins.adsbygoogle,[id^=\"google_ads\"],[id^=\"div-gpt-ad\"],"
                    + "[id^=\"yandex_rtb\"],[id^=\"adfox_\"],iframe[src*=\"doubleclick.net\"],"
                    + "iframe[src*=\"googlesyndication\"],iframe[src*=\"adfox\"],"
                    + ".adsbox,.ad-banner,.banner-ads,.adsbygoogle{display:none!important}';"
                    + "(document.head||document.documentElement).appendChild(s);})();";

    private FrameLayout webHost, fullHost;
    private View bar;
    private TextView barText;
    private ProgressBar progress;
    private Button btnFilter, btnCursor;
    private CursorView cursor;
    private WebView web;

    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;

    private Prefs prefs;
    private String startUrl, startSite;
    private volatile String pageSite = "";
    private volatile boolean filtering;
    private boolean cursorMode = true;
    private final AtomicInteger blocked = new AtomicInteger();
    private long lastUserInput, lastAllowedNav, touchDownTime;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable barUpdate = this::updateBar;
    private Bitmap poster;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_web);
        prefs = new Prefs(this);
        startUrl = getIntent().getStringExtra(EXTRA_URL);
        if (startUrl == null) {
            finish();
            return;
        }
        startSite = Util.siteKey(Util.hostOf(startUrl));
        pageSite = startSite;
        filtering = prefs.adblock() && !prefs.isUnfiltered(startSite);

        webHost = findViewById(R.id.web_host);
        fullHost = findViewById(R.id.full_host);
        bar = findViewById(R.id.bar);
        barText = findViewById(R.id.bar_text);
        progress = findViewById(R.id.progress);
        btnFilter = findViewById(R.id.btn_filter);
        btnCursor = findViewById(R.id.btn_cursor);
        cursor = findViewById(R.id.cursor);

        findViewById(R.id.btn_back).setOnClickListener(v -> onBack());
        findViewById(R.id.btn_reload).setOnClickListener(v -> { if (web != null) web.reload(); focusPage(); });
        findViewById(R.id.btn_close).setOnClickListener(v -> finish());
        btnFilter.setOnClickListener(v -> toggleFilter());
        btnCursor.setOnClickListener(v -> {
            cursorMode = !cursorMode;
            cursor.setVisibility(cursorMode ? View.VISIBLE : View.GONE);
            updateBar();
            focusPage();
        });

        createWebView();
        web.loadUrl(startUrl);
        updateBar();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void createWebView() {
        web = new WebView(this);
        web.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        web.setBackgroundColor(Color.BLACK);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);            // нужен веб-плеерам
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(true);       // чтобы перехватывать window.open и не открывать окна
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setGeolocationEnabled(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);

        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        webHost.addView(web);
        focusPage();
    }

    private void destroyWebView() {
        if (web == null) return;
        exitFullscreen();
        webHost.removeView(web);
        web.stopLoading();
        web.setWebChromeClient(null);
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("about:blank");
        web.clearHistory();
        web.removeAllViews();
        web.destroy();
        web = null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            web.resumeTimers();
        }
    }

    @Override
    protected void onPause() {
        if (web != null) {
            web.onPause();
            web.pauseTimers(); // скрытая страница не крутит JS и не тратит CPU
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        destroyWebView();
        if (poster != null) {
            poster.recycle();
            poster = null;
        }
        super.onDestroy();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (web != null && level >= TRIM_MEMORY_RUNNING_LOW) web.clearCache(false); // только кэш в ОЗУ
    }

    // ---------------------------------------------------------------- фильтрация

    private boolean isProtectedMedia(Uri u) {
        String p = u.getPath();
        if (p == null) return false;
        p = p.toLowerCase(Locale.ROOT);
        return p.endsWith(".m3u8") || p.endsWith(".mpd");
    }

    private WebResourceResponse emptyResponse() {
        return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
    }

    private void countBlocked() {
        blocked.incrementAndGet();
        h.removeCallbacks(barUpdate);
        h.postDelayed(barUpdate, 400);
    }

    /** @return true — переход запрещён. */
    private boolean blockNavigation(Uri u, boolean gesture, boolean mainFrame, boolean redirect) {
        String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        if (!scheme.equals("http") && !scheme.equals("https")) {
            if (scheme.equals("about") || scheme.equals("data") || scheme.equals("blob") || scheme.equals("javascript")) {
                return false;
            }
            countBlocked();
            toast("Заблокирован переход во внешнее приложение (" + scheme + ":)");
            return true;
        }
        if (!mainFrame) return false;

        String host = u.getHost();
        long now = SystemClock.uptimeMillis();
        boolean byUser = gesture || now - lastUserInput < 1500 || (redirect && now - lastAllowedNav < 5000);

        if (filtering && host != null && AdBlocker.get() != null && AdBlocker.get().isBlocked(host)) {
            countBlocked();
            toast("Заблокирован рекламный переход: " + host);
            return true;
        }
        if (Util.siteKey(host).equals(pageSite)) {
            lastAllowedNav = now;
            return false;
        }
        if (!byUser) {
            countBlocked();
            toast("Заблокировано автоматическое перенаправление на " + host);
            return true;
        }
        lastAllowedNav = now;
        return false;
    }

    private final class Client extends WebViewClient {

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            if (!filtering || req.isForMainFrame()) return null;
            Uri u = req.getUrl();
            String host = u.getHost();
            if (host == null) return null;
            if (isProtectedMedia(u)) return null;                       // манифесты видео — всегда
            if (Util.siteKey(host).equals(pageSite)) return null;       // ресурсы самого сайта — всегда
            AdBlocker ab = AdBlocker.get();
            if (ab != null && ab.isBlocked(host)) {
                countBlocked();
                return emptyResponse();
            }
            return null;
        }

        @TargetApi(Build.VERSION_CODES.N)
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            return blockNavigation(req.getUrl(), req.hasGesture(), req.isForMainFrame(), req.isRedirect());
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            // Вызывается только на Android 5–6.
            return blockNavigation(Uri.parse(url), false, true, false);
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            pageSite = Util.siteKey(Util.hostOf(url));
            progress.setVisibility(View.VISIBLE);
            updateBar();
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            progress.setVisibility(View.INVISIBLE);
            if (filtering) view.evaluateJavascript(COSMETIC_JS, null);
            updateBar();
        }

        @SuppressWarnings("deprecation")
        @Override
        public void onReceivedError(WebView view, int code, String description, String failingUrl) {
            barText.setText("Ошибка загрузки: " + description + " — нажмите ⟳");
        }

        @TargetApi(Build.VERSION_CODES.O)
        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            // Система закрыла движок страницы (обычно из-за нехватки памяти). Не падаем и не
            // перезапускаем страницу по кругу — закрываем экран и сообщаем пользователю.
            if (view == web) {
                destroyWebView();
                toast("Страница закрыта: не хватило памяти устройства. Попробуйте открыть её снова.");
                finish();
            }
            return true;
        }
    }

    private final class Chrome extends WebChromeClient {

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            countBlocked();
            toast("Всплывающее окно заблокировано");
            return false;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (customView != null) {
                callback.onCustomViewHidden();
                return;
            }
            customView = view;
            customCallback = callback;
            fullHost.addView(view, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            fullHost.setVisibility(View.VISIBLE);
            bar.setVisibility(View.GONE);
            progress.setVisibility(View.GONE);
            webHost.setVisibility(View.INVISIBLE);
        }

        @Override
        public void onHideCustomView() {
            exitFullscreen();
        }

        @Override
        public void onProgressChanged(WebView view, int p) {
            progress.setProgress(p);
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            request.deny(); // камера, микрофон и т.п. не нужны
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
            callback.invoke(origin, false, false);
        }

        @Override
        public Bitmap getDefaultVideoPoster() {
            if (poster == null) poster = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            return poster;
        }
    }

    private void exitFullscreen() {
        if (customView == null) return;
        View v = customView;
        WebChromeClient.CustomViewCallback cb = customCallback;
        customView = null;
        customCallback = null;
        fullHost.removeView(v);
        fullHost.setVisibility(View.GONE);
        webHost.setVisibility(View.VISIBLE);
        bar.setVisibility(View.VISIBLE);
        if (cb != null) cb.onCustomViewHidden();
        focusPage();
    }

    private void toggleFilter() {
        if (!prefs.adblock()) {
            toast("Блокировка рекламы выключена в настройках приложения");
            return;
        }
        filtering = !filtering;
        prefs.setUnfiltered(startSite, !filtering);
        toast(filtering ? "Фильтрация для " + startSite + " включена" : "Фильтрация для " + startSite + " отключена");
        updateBar();
        if (web != null) web.reload();
    }

    private void updateBar() {
        btnFilter.setText(filtering ? "Реклама: блок" : "Реклама: без фильтра");
        btnCursor.setText(cursorMode ? "Курсор: вкл" : "Курсор: выкл");
        String host = web != null && web.getUrl() != null ? Util.hostOf(web.getUrl()) : Util.hostOf(startUrl);
        barText.setText(host + " · заблокировано: " + blocked.get() + " · Menu — панель");
    }

    // ---------------------------------------------------------------- пульт и курсор

    private void focusPage() {
        if (customView != null) customView.requestFocus();
        else if (web != null) web.requestFocus();
    }

    private void onBack() {
        if (customView != null) {
            exitFullscreen();
            return;
        }
        if (web != null && web.canGoBack()) {
            web.goBack();
            return;
        }
        finish();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;

        if (k == KeyEvent.KEYCODE_BACK) {
            if (!down && !e.isCanceled()) onBack();
            return true;
        }
        if (k == KeyEvent.KEYCODE_MENU) {
            if (down && customView == null) {
                if (bar.hasFocus()) focusPage();
                else findViewById(R.id.btn_back).requestFocus();
            }
            return true;
        }
        if (bar.getVisibility() == View.VISIBLE && bar.hasFocus()) {
            if (down && k == KeyEvent.KEYCODE_DPAD_DOWN) {
                focusPage();
                return true;
            }
            return super.dispatchKeyEvent(e);
        }
        if (cursorMode && isCursorKey(k)) {
            handleCursorKey(e, down);
            return true;
        }
        if (down) lastUserInput = SystemClock.uptimeMillis();
        return super.dispatchKeyEvent(e);
    }

    private static boolean isCursorKey(int k) {
        return k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN
                || k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT
                || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER;
    }

    private void handleCursorKey(KeyEvent e, boolean down) {
        int k = e.getKeyCode();
        if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER) {
            if (down && e.getRepeatCount() == 0) touch(MotionEvent.ACTION_DOWN);
            else if (!down) touch(MotionEvent.ACTION_UP);
            return;
        }
        if (!down) return;

        float d = getResources().getDisplayMetrics().density;
        float step = 10 * d * Math.min(1 + e.getRepeatCount() / 3f, 5f); // ускорение при удержании
        float dx = 0, dy = 0;
        if (k == KeyEvent.KEYCODE_DPAD_LEFT) dx = -step;
        else if (k == KeyEvent.KEYCODE_DPAD_RIGHT) dx = step;
        else if (k == KeyEvent.KEYCODE_DPAD_UP) dy = -step;
        else dy = step;

        // Курсор не заходит на панель: верхняя граница — верх области страницы.
        float minY = customView != null ? 0 : webHost.getTop() + ((View) webHost.getParent()).getTop();
        int edge = cursor.moveBy(dx, dy, minY);
        View target = customView != null ? customView : web;
        if (target == null || customView != null) return;

        int scroll = (int) (step * 3);
        if ((edge & CursorView.EDGE_BOTTOM) != 0) web.scrollBy(0, scroll);
        else if ((edge & CursorView.EDGE_TOP) != 0) {
            if (web.canScrollVertically(-1)) web.scrollBy(0, -scroll);
            else findViewById(R.id.btn_back).requestFocus(); // упёрлись вверх — на панель
        }
        if ((edge & CursorView.EDGE_LEFT) != 0) web.scrollBy(-scroll, 0);
        else if ((edge & CursorView.EDGE_RIGHT) != 0) web.scrollBy(scroll, 0);
    }

    /** Синтетическое касание в точке курсора — страница воспринимает его как нажатие пользователя. */
    private void touch(int action) {
        View target = customView != null ? customView : web;
        if (target == null) return;
        int[] tl = new int[2], cl = new int[2];
        target.getLocationOnScreen(tl);
        cursor.getLocationOnScreen(cl);
        float x = cursor.cx() + cl[0] - tl[0];
        float y = cursor.cy() + cl[1] - tl[1];
        long now = SystemClock.uptimeMillis();
        if (action == MotionEvent.ACTION_DOWN) touchDownTime = now;
        lastUserInput = now;
        MotionEvent ev = MotionEvent.obtain(touchDownTime, now, action, x, y, 0);
        ev.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        target.dispatchTouchEvent(ev);
        ev.recycle();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
