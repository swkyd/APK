# Media3 поставляет собственные consumer-правила; дополнительных не требуется.
# Пользовательский View, создаваемый из XML:
-keep class app.litestream.tv.CursorView { <init>(...); }
